package dev.zengcode.features.lazyjdbc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LazyJdbcService {

    private static final Logger log = LoggerFactory.getLogger(LazyJdbcService.class);
    private final ProductRepository productRepository;

    public LazyJdbcService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Transactional
    public void noDb() {
        log.info("--- [noDb] Transaction started ---");
        simulateExternalCall();
        log.info("--- [noDb] Transaction end (no DB accessed) ---");
    }

    @Transactional
    public void externalThenDb() {
        log.info("--- [externalThenDb] Transaction started ---");
        
        simulateExternalCall();
        
        log.info("--- [externalThenDb] Before database access ---");
        productRepository.count();
        log.info("--- [externalThenDb] After database access ---");
        
        log.info("--- [externalThenDb] Transaction end ---");
    }

    @Transactional
    public void dbFirst() {
        log.info("--- [dbFirst] Transaction started ---");
        
        log.info("--- [dbFirst] Before database access ---");
        productRepository.count();
        log.info("--- [dbFirst] After database access ---");
        
        simulateExternalCall();
        
        log.info("--- [dbFirst] Transaction end ---");
    }

    private void simulateExternalCall() {
        log.info("--- Before simulated external call ---");
        try {
            // Simulate a slow external API call (2 seconds)
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        log.info("--- After simulated external call ---");
    }
}
