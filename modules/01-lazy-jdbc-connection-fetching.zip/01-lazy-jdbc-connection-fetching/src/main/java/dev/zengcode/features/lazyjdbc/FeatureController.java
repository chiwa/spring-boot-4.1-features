package dev.zengcode.features.lazyjdbc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/lazy-jdbc")
public class FeatureController {

    private final LazyJdbcService lazyJdbcService;

    public FeatureController(LazyJdbcService lazyJdbcService) {
        this.lazyJdbcService = lazyJdbcService;
    }

    /**
     * Scenario 1: Transaction starts, but no database query is ever executed.
     * What it does: Calls a transactional method that only simulates an external API call.
     * Demo purpose: Proves that with Lazy Fetching, a Hikari connection is NEVER acquired
     * from the pool if no SQL is actually run, saving valuable connection resources.
     */
    @GetMapping("/no-db")
    public String noDb() {
        lazyJdbcService.noDb();
        return "Executed noDb flow";
    }

    /**
     * Scenario 2: Slow external call happens FIRST, followed by a database query.
     * What it does: Simulates a 2-second external delay, then queries the database.
     * Demo purpose: Shows that the JDBC connection is acquired lazily ONLY AFTER the 
     * 2-second delay finishes. It prevents the connection from sitting idle and blocking 
     * the pool while waiting for the external API.
     */
    @GetMapping("/external-then-db")
    public String externalThenDb() {
        lazyJdbcService.externalThenDb();
        return "Executed externalThenDb flow";
    }

    /**
     * Scenario 3: Database query happens FIRST, followed by a slow external call.
     * What it does: Queries the database immediately, then simulates a 2-second external delay.
     * Demo purpose: Shows the traditional problem. Since the DB is accessed first, the 
     * connection is acquired immediately and held for the entire 2 seconds, which can 
     * quickly exhaust the connection pool under high load.
     */
    @GetMapping("/db-first")
    public String dbFirst() {
        lazyJdbcService.dbFirst();
        return "Executed dbFirst flow";
    }
}
