# Lazy JDBC Connection Fetching

## Objective
Demonstrate the benefits of Lazy JDBC Connection Fetching in Spring Boot 4.1.

## Purpose & Expectation
In standard Spring applications, when a method is annotated with `@Transactional`, the underlying transaction manager immediately fetches a JDBC connection from the connection pool (like HikariCP), even before any database queries are actually executed.

If a transaction contains a slow operation *before* the first database call (e.g., an external API call, a complex calculation), the JDBC connection sits idle in the transaction while the pool's capacity is tied up. This leads to connection pool exhaustion under high load.

**Lazy JDBC Connection Fetching** delays acquiring the JDBC connection from the pool until the exact moment a database query is executed. 

## How to Run
1. Ensure the PostgreSQL database is running via `docker compose`:
   ```bash
   docker compose -f infra/docker-compose.yml up postgres -d
   ```
2. Start this module.
3. Observe the application logs. We have configured `maximum-pool-size=2` to simulate a highly constrained pool, and added `DEBUG` logs for `HikariPool` and `JpaTransactionManager` to see connection acquisition in real time.

## Expected Behavior & Comparison

Hit the following endpoints to see the difference in behavior:

- **GET `/lazy-jdbc/no-db`**: 
  - Simulates a business flow with `@Transactional` but no DB interaction.
  - **Behavior**: You will see the transaction start and end, but *no Hikari connection is ever acquired*.
  
- **GET `/lazy-jdbc/external-then-db`**:
  - Simulates a slow external call (`Thread.sleep(2000)`), followed by a DB call.
  - **Behavior**: The transaction starts, but the Hikari connection is *only acquired after* the 2-second sleep finishes, preventing the pool from being unnecessarily exhausted during the sleep.

- **GET `/lazy-jdbc/db-first`**:
  - Hits the database first, then performs the 2-second sleep.
  - **Behavior**: The Hikari connection is acquired immediately and held for the entire 2 seconds while the sleep runs. This demonstrates the standard behavior when DB access cannot be deferred.
